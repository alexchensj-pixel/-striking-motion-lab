// Pruebas de la fuente Airtable de MI SML. NO usa el Airtable real: levanta un servidor HTTP local que imita POST /v0/{base}/{tabla}/listRecords
// (solo entiende las dos fórmulas que genera la fuente) y comprueba, con peticiones HTTP reales, qué se pide y qué se devuelve.
// Lo que estas pruebas NO demuestran: que los nombres de campo coincidan con la base real (scripts/airtable-check.mjs) ni la validación real del JWT.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { atender, RUTA_ME } from './miSml.js';
import { crearFuenteAirtable, CAMPOS, TABLAS, BASE_ID_POR_DEFECTO } from './miSmlAirtable.js';

const TOKEN = 'patTEST.secreto-de-prueba';
const rec = (id, fields, createdTime = '2026-01-01T00:00:00.000Z') => ({ id, createdTime, fields });
const id = (n) => `rec${String(n).padStart(14, '0')}`;

// Base simulada con DOS clientes (A y B) con datos claramente distintos.
const tablas = {
  [TABLAS.contactos]: [
    rec(id(1), { 'Auth0 ID': 'auth0|A', Nombre: 'Cliente A', 'Bonos y planes': [id(11)], Pagos: [id(21), id(22)], 'SML — Movement Analysis': [id(31), id(32)] }),
    rec(id(2), { 'Auth0 ID': 'auth0|B', Nombre: 'Cliente B', 'Bonos y planes': [id(12)], Pagos: [id(23)], 'SML — Movement Analysis': [id(33)] }),
    rec(id(3), { Nombre: 'Sin vincular' }),
    rec(id(4), { 'Auth0 ID': 'auth0|DUP', Nombre: 'Dup 1' }),
    rec(id(5), { 'Auth0 ID': 'auth0|DUP', Nombre: 'Dup 2' }),
    rec(id(6), { 'Auth0 ID': 'auth0|vacio', Nombre: 'Sin nada vinculado' }),
    rec(id(7), { 'Auth0 ID': 'auth0|neg', Nombre: 'Restantes negativas', 'Bonos y planes': [id(13)] }),
  ],
  [TABLAS.bonos]: [
    rec(id(11), { Tipo: 'Striker', Registro: 'Registro interno A', 'Clases contratadas': 10, 'Sesiones registradas (auto)': 4, 'Sesiones restantes (auto)': 6 }),
    rec(id(12), { Registro: 'Arsenal B', 'Clases contratadas': 20, 'Sesiones registradas (auto)': 1 }), // sin «Tipo» → el plan sale de «Registro»; sin «restantes» → se calcula
    rec(id(13), { Tipo: 'Plan sobrepasado', 'Clases contratadas': 5, 'Sesiones registradas (auto)': 7, 'Sesiones restantes (auto)': -2 }),
  ],
  [TABLAS.pagos]: [
    rec(id(21), { Estado: 'Pagado', Importe: 30 }, '2026-02-01T00:00:00.000Z'),
    rec(id(22), { Estado: 'Pendiente', Importe: 45.5 }, '2026-03-01T00:00:00.000Z'),
    rec(id(23), { Estado: 'Pagado B', Importe: 999 }),
  ],
  [TABLAS.analisis]: [
    rec(id(31), { 'Visible al cliente': true, Análisis: 'Análisis A visible', 'Fecha evaluación': '2026-03-10', 'Texto cliente — Observación': 'Observación para A', 'Texto cliente — Evolución': 'Evolución de A', Observación: 'SOLO ENTRENADOR 1', 'Hipótesis entrenador': 'SOLO ENTRENADOR 2' }),
    rec(id(32), { 'Visible al cliente': false, Análisis: 'Borrador A interno', 'Texto cliente — Observación': 'NO PUBLICAR' }),
    rec(id(33), { 'Visible al cliente': true, Análisis: 'Análisis de B', 'Texto cliente — Observación': 'Solo para B' }),
  ],
};

async function airtableFalso({ fallar = null } = {}) {
  const peticiones = [];
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => { raw += c; });
    req.on('end', () => {
      const m = /^\/v0\/([^/]+)\/([^/]+)\/listRecords$/.exec(req.url);
      const body = JSON.parse(raw || '{}');
      peticiones.push({ method: req.method, base: m?.[1], tabla: m && decodeURIComponent(m[2]), auth: req.headers.authorization, formula: body.filterByFormula });
      if (fallar) { res.statusCode = fallar; return res.end('{"error":"detalle interno con secreto"}'); }
      if (!m || req.method !== 'POST' || req.headers.authorization !== `Bearer ${TOKEN}`) { res.statusCode = 401; return res.end('{}'); }
      const filas = tablas[decodeURIComponent(m[2])] || [];
      const f = body.filterByFormula;
      let sel;
      const porAuth0 = /^TRIM\(\{Auth0 ID\}\)="((?:[^"\\]|\\.)*)"$/.exec(f);
      if (porAuth0) { const v = porAuth0[1].replace(/\\(.)/g, '$1'); sel = filas.filter((r) => String(r.fields['Auth0 ID'] ?? '').trim() === v); }
      else if (/^OR\((RECORD_ID\(\)="rec[A-Za-z0-9]{14}",?)+\)$/.test(f)) { const ids = [...f.matchAll(/"(rec[A-Za-z0-9]{14})"/g)].map((x) => x[1]); sel = filas.filter((r) => ids.includes(r.id)); }
      else { res.statusCode = 422; return res.end('{}'); }
      res.setHeader('content-type', 'application/json');
      res.end(JSON.stringify({ records: sel }));
    });
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  return { url: `http://127.0.0.1:${server.address().port}/v0`, peticiones, cerrar: () => new Promise((r) => server.close(r)) };
}

const verify = async (t) => ({ tokenA: { sub: 'auth0|A' }, tokenB: { sub: 'auth0|B' }, tokenX: { sub: 'auth0|NoExiste' }, tokenSin: { sub: 'auth0|DUP' }, tokenDup: { sub: 'auth0|DUP' }, tokenVacio: { sub: 'auth0|vacio' } })[t] ?? Promise.reject({ kind: 'invalid' });
const pedir = (fuente, tokenName, logs = []) => atender({ method: 'GET', pathname: RUTA_ME, authorization: `Bearer ${tokenName}` }, { verify, fuente, log: (...a) => logs.push(a.join(' ')) });
const nueva = (fa, extra = {}) => crearFuenteAirtable({ env: { AIRTABLE_TOKEN: TOKEN }, apiUrl: fa.url, log: () => {}, ...extra });

test('CLIENTE VINCULADO · /me devuelve sus datos reales (200 connected) con el contrato esperado', async () => {
  const fa = await airtableFalso();
  try {
    const r = await pedir(nueva(fa), 'tokenA');
    assert.equal(r.status, 200);
    assert.deepEqual(r.body, {
      session: 'valid', data: 'connected',
      client: {
        nombre: 'Cliente A', plan: 'Striker',
        pago: { estado: 'Pendiente', importePendiente: null }, // «Pagos» no tiene importe pendiente: no se calcula ni se suma «Importe»
        clases: { contratadas: 10, realizadas: 4, restantes: 6 },
        movementAnalysis: [{ titulo: 'Análisis A visible', resumen: 'Observación para A\n\nEvolución de A', fecha: '2026-03-10' }],
      },
    });
    const txt = JSON.stringify(r.body);
    for (const prohibido of ['Cliente B', 'Arsenal', 'Solo para B', 'Pagado B', 'NO PUBLICAR', 'SOLO ENTRENADOR', 'Registro interno', 'Borrador', 'auth0|', 'patTEST']) assert.equal(txt.includes(prohibido), false, prohibido);
  } finally { await fa.cerrar(); }
});

test('AISLAMIENTO · cada token ve solo lo suyo y A nunca consulta los registros de B', async () => {
  const fa = await airtableFalso();
  try {
    const fuente = nueva(fa);
    const a = await pedir(fuente, 'tokenA');
    const peticionesA = fa.peticiones.splice(0).map((p) => p.formula).join(' ');
    const b = await pedir(fuente, 'tokenB');
    assert.equal(a.body.client.nombre, 'Cliente A');
    assert.equal(b.body.client.nombre, 'Cliente B');
    assert.equal(b.body.client.plan, 'Arsenal B');
    assert.deepEqual(b.body.client.clases, { contratadas: 20, realizadas: 1, restantes: 19 }); // restantes = contratadas − realizadas (no había campo)
    assert.equal(b.body.client.pago.importePendiente, null); // aunque «Importe» sea 999: no es «pendiente»
    for (const ajeno of [id(12), id(23), id(33), id(2), 'auth0|B']) assert.equal(peticionesA.includes(ajeno), false, `A pidió ${ajeno}`);
  } finally { await fa.cerrar(); }
});

test('SIN CORRESPONDENCIA · sub desconocido → not-connected, sin datos de nadie, y solo se consulta Contactos', async () => {
  const fa = await airtableFalso();
  try {
    const r = await pedir(nueva(fa), 'tokenX');
    assert.deepEqual([r.status, r.body], [200, { session: 'valid', data: 'not-connected' }]);
    assert.deepEqual(fa.peticiones.map((p) => p.tabla), [TABLAS.contactos]);
  } finally { await fa.cerrar(); }
});

test('AUTH0 ID DUPLICADO en Contactos → not-connected (no se elige a ninguno) y queda registrado', async () => {
  const fa = await airtableFalso();
  try {
    const logs = [];
    const r = await pedir(nueva(fa, { log: (...a) => logs.push(a.join(' ')) }), 'tokenDup');
    assert.deepEqual(r.body, { session: 'valid', data: 'not-connected' });
    assert.equal(logs.length, 1);
    assert.equal(fa.peticiones.length, 1);
  } finally { await fa.cerrar(); }
});

test('contacto vinculado pero sin nada relacionado → datos null/vacíos, sin inventar, sin consultar otras tablas', async () => {
  const fa = await airtableFalso();
  try {
    const r = await pedir(nueva(fa), 'tokenVacio');
    assert.deepEqual(r.body.client, { nombre: 'Sin nada vinculado', plan: null, pago: { estado: null, importePendiente: null }, clases: { contratadas: null, realizadas: null, restantes: null }, movementAnalysis: [] });
    assert.equal(fa.peticiones.length, 1);
  } finally { await fa.cerrar(); }
});

test('inyección: un sub con comillas/barras no rompe la fórmula ni devuelve a otro cliente', async () => {
  const fa = await airtableFalso();
  try {
    const fuente = nueva(fa);
    for (const sub of ['x") , "1"="1', 'auth0|A" OR "1"="1', 'a\\', 'auth0|A\n', '', '   ']) {
      assert.deepEqual(await fuente.obtener({ sub }), { estado: 'not-connected' }, JSON.stringify(sub));
    }
    assert.equal(await fuente.obtener({}).then((r) => r.estado), 'not-connected');
  } finally { await fa.cerrar(); }
});

test('llamada a Airtable: POST con el token solo en la cabecera Authorization, a la base correcta', async () => {
  const fa = await airtableFalso();
  try {
    await pedir(nueva(fa), 'tokenA');
    assert.ok(fa.peticiones.length >= 2);
    for (const p of fa.peticiones) { assert.equal(p.method, 'POST'); assert.equal(p.base, BASE_ID_POR_DEFECTO); assert.equal(p.auth, `Bearer ${TOKEN}`); assert.equal(String(p.formula).includes(TOKEN), false); }
  } finally { await fa.cerrar(); }
});

test('Airtable falla (401/422/500) → 500 genérico; ni el token ni el cuerpo del error llegan al cliente ni al log', async () => {
  for (const status of [401, 422, 500]) {
    const fa = await airtableFalso({ fallar: status });
    try {
      const logs = [];
      const r = await pedir(nueva(fa), 'tokenA', logs);
      assert.deepEqual([r.status, r.body], [500, { error: 'internal' }]);
      const todo = logs.join(' ');
      assert.equal(todo.includes('secreto') || todo.includes(TOKEN), false);
      assert.match(todo, new RegExp(`airtable-${status}`));
    } finally { await fa.cerrar(); }
  }
});

test('sin AIRTABLE_TOKEN la fuente no se puede crear (la función usa «no conectado» en su lugar)', () => {
  assert.throws(() => crearFuenteAirtable({ env: {} }));
});

test('el token de Airtable no aparece en ningún archivo del frontend ni en variables VITE_', async () => {
  const { readFileSync, readdirSync, statSync } = await import('node:fs');
  const { join } = await import('node:path');
  const recorrer = (d) => readdirSync(d).flatMap((n) => { const p = join(d, n); return statSync(p).isDirectory() ? recorrer(p) : [p]; });
  const codigo = recorrer(new URL('../src', import.meta.url).pathname).filter((p) => /\.(jsx?|html|css)$/.test(p));
  for (const p of codigo) assert.equal(/airtable/i.test(readFileSync(p, 'utf8').replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '')), false, `${p} menciona Airtable en código`);
  assert.equal(/VITE_AIRTABLE/.test(readFileSync(new URL('../.env.example', import.meta.url), 'utf8')), false);
  assert.ok(CAMPOS.contactos.auth0);
});

test('restantes nunca es negativo (más sesiones registradas que contratadas)', async () => {
  const fa = await airtableFalso();
  try {
    const r = await nueva(fa).obtener({ sub: 'auth0|neg' });
    assert.equal(r.estado, 'connected');
    assert.equal(r.client.plan, 'Plan sobrepasado');
    assert.deepEqual(r.client.clases, { contratadas: 5, realizadas: 7, restantes: 0 });
  } finally { await fa.cerrar(); }
});

test('Movement Analysis: el resumen solo puede salir de campos «Texto cliente — …» (nunca de los internos del entrenador)', () => {
  const nombres = [CAMPOS.analisis.resumen].flat();
  assert.ok(nombres.length > 0);
  for (const n of nombres) assert.match(n, /^Texto cliente — /);
});
