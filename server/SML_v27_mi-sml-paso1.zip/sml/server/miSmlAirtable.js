// MI SML · FUENTE DE DATOS PRIVADA (Airtable) — SOLO SERVIDOR. Se usa desde netlify/functions/mi-sml-me.mjs y desde el servidor de desarrollo (vite.config.js).
// Nada de este archivo llega al navegador: el token de Airtable vive únicamente en variables de entorno del servidor (sin prefijo VITE_).
//
//   server/miSml.js  →  fuente.obtener({ sub })  →  este archivo  →  Airtable (API REST, token de solo lectura)
//
// IDENTIDAD → CONTACTO. El único identificador que el token de Auth0 aporta hoy es el `sub` (server/miSmlAuth.js). El `sub` es estable: no cambia
// aunque la persona cambie de email o de método de acceso. Se busca en Contactos por el campo `Auth0 ID` (ver CAMPOS.contactos.auth0).
// Ese campo ya existe en Contactos (texto de una línea); hay que rellenarlo a mano con el «user_id» de Auth0 de cada cliente (es el único paso externo).
//
// AISLAMIENTO (3 capas):
//   1. Se busca el contacto por igualdad EXACTA con el `sub` del token validado. Sin coincidencia → 'not-connected' (no se muestra nada).
//      Si hubiera 2+ contactos con el mismo Auth0 ID (error de datos) → tampoco se muestra nada y se registra en el log del servidor.
//   2. Bonos, pagos y análisis NO se buscan por nombre ni por email: se piden por los IDs de registro que figuran en los campos vinculados
//      del PROPIO contacto encontrado. Solo se leen registros de ese contacto.
//   3. Aun así, cada registro devuelto se vuelve a comprobar contra esos IDs antes de usarse. El análisis solo sale si «visible para el cliente» es true.
//
// NO se inventa nada: un campo que no existe o está vacío se devuelve como null. Los nombres de campo están en CAMPOS (un único sitio); si en
// Airtable se llaman de otra forma, se corrigen ahí. `node scripts/airtable-check.mjs` los contrasta con la base real sin mostrar datos de clientes.

export const BASE_ID_POR_DEFECTO = 'appNrxsvRyTYBYHlC'; // Striking Motion Lab — CRM (el ID de base no es un secreto)

export const TABLAS = {
  contactos: 'Contactos',
  bonos: 'Bonos y planes',
  pagos: 'Pagos',
  analisis: 'SML — Movement Analysis',
};

// NOMBRES DE CAMPO VERIFICADOS el 2026-10-07 contra la estructura real de la base «Striking Motion Lab — CRM» (solo nombres y tipos de campo; no se leyó ningún
// dato de clientes). Si se renombra algo en Airtable, volver a contrastar con `scripts/airtable-check.mjs`.
// `null` = ese dato no existe en la base: se devuelve null (nunca un valor supuesto). Una lista […] = se unen, en ese orden, los que tengan texto.
export const CAMPOS = {
  contactos: {
    auth0: 'Auth0 ID',                     // texto de una línea (ya creado en Contactos). Valor = user_id de Auth0 (p. ej. «auth0|64f…»); se rellena a mano por cliente.
    nombre: 'Nombre',
    bonos: 'Bonos y planes',               // campo vinculado de Contactos → tabla «Bonos y planes»
    pagos: 'Pagos',                        // campo vinculado de Contactos → tabla «Pagos»
    analisis: 'SML — Movement Analysis',   // campo vinculado de Contactos → tabla «SML — Movement Analysis»
  },
  bonos: {
    plan: 'Tipo',                          // nombre del plan que ve el cliente
    planRespaldo: 'Registro',              // si «Tipo» está vacío (es el campo principal de la tabla)
    estado: null,                          // «Bonos y planes» no tiene estado de vigencia («Estado pago» es de cobro, no de vigencia): se toma el bono más reciente
    contratadas: 'Clases contratadas',
    realizadas: 'Sesiones registradas (auto)', // recuento de las Sesiones vinculadas al bono: lo calcula Airtable
    restantes: 'Sesiones restantes (auto)',    // fórmula de Airtable; si faltara o estuviera vacía y hay contratadas y realizadas, restantes = contratadas − realizadas (mínimo 0)
  },
  pagos: {
    estado: 'Estado',
    pendiente: null,                       // APAGADO: «Pagos» no tiene importe pendiente (solo «Importe» de cada pago y su «Estado»); sumar «Importe» a ciegas contaría también lo ya cobrado
  },
  analisis: {
    visible: 'Visible al cliente',         // casilla: solo se devuelven los análisis con la casilla marcada
    titulo: 'Análisis',                    // campo principal de la tabla
    resumen: [                             // SOLO los «Texto cliente — …». El resto (Observación, Interpretación, Hipótesis entrenador…) es interno y NUNCA se envía al cliente
      'Texto cliente — Observación',
      'Texto cliente — Por qué importa',
      'Texto cliente — Qué trabajamos',
      'Texto cliente — Evolución',
      'Texto cliente — Siguiente objetivo',
    ],
    fecha: 'Fecha evaluación',
  },
};

// Valores de «Estado» (Bonos y planes) que cuentan como plan vigente. Hoy NO se usa: CAMPOS.bonos.estado es null porque esa tabla no tiene estado de vigencia.
// Si algún día se crea ese campo, poner su nombre en CAMPOS.bonos.estado y aquí las opciones reales.
export const BONO_VIGENTE = ['Activo'];

const API = 'https://api.airtable.com/v0';
const ID_REGISTRO = /^rec[A-Za-z0-9]{14}$/;
const CONTROL = /[\u0000-\u001f\u007f]/;

// ---- utilidades ------------------------------------------------------------------------------------------------------------------
const esc = (s) => String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"'); // literal de cadena de fórmula de Airtable
const primero = (v) => (Array.isArray(v) ? v[0] : v);
const texto = (v) => { const x = primero(v); return typeof x === 'string' ? (x.trim() || null) : typeof x === 'number' ? String(x) : null; };
const numero = (v) => { const x = primero(v); return typeof x === 'number' && Number.isFinite(x) ? x : null; };
const campo = (r, nombre) => (nombre ? r?.fields?.[nombre] : undefined);
const idsDe = (v) => (Array.isArray(v) ? [...new Set(v.filter((x) => typeof x === 'string' && ID_REGISTRO.test(x)))] : []);
const masReciente = (a, b) => String(b.createdTime || '').localeCompare(String(a.createdTime || ''));
const unirTextos = (valores) => valores.filter((v) => typeof v === 'string' && v.trim()).map((v) => v.trim()).join('\n\n') || null; // párrafos separados por línea en blanco; null si no hay ninguno
const filtroIds = (ids) => `OR(${ids.map((id) => `RECORD_ID()="${id}"`).join(',')})`;

export function configuradoAirtable(env = process.env) {
  return Boolean(String(env.AIRTABLE_TOKEN ?? '').trim());
}

// Crea la fuente de datos. `fetchImpl` y `apiUrl` son inyectables SOLO para las pruebas. Devuelve { obtener({ sub }) }.
export function crearFuenteAirtable({ env = process.env, fetchImpl = globalThis.fetch, apiUrl = API, log = console.error } = {}) {
  const token = String(env.AIRTABLE_TOKEN ?? '').trim();
  const baseId = String(env.AIRTABLE_BASE_ID ?? '').trim() || BASE_ID_POR_DEFECTO;
  if (!token) throw new Error('AIRTABLE_TOKEN no configurado');

  // Lista TODOS los registros que cumplen la fórmula (paginando). POST listRecords: la fórmula va en el cuerpo, sin límite de URL.
  async function listar(tabla, filterByFormula) {
    const registros = [];
    let offset;
    for (let pagina = 0; pagina < 10; pagina++) {
      const res = await fetchImpl(`${apiUrl}/${baseId}/${encodeURIComponent(tabla)}/listRecords`, {
        method: 'POST',
        headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
        body: JSON.stringify({ filterByFormula, pageSize: 100, ...(offset ? { offset } : null) }),
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) { const e = new Error('airtable'); e.code = `airtable-${res.status}`; e.tabla = tabla; throw e; } // nunca el cuerpo ni el token
      const j = await res.json();
      registros.push(...(j.records || []));
      offset = j.offset;
      if (!offset) return registros;
    }
    const e = new Error('airtable'); e.code = 'airtable-demasiadas-paginas'; throw e;
  }

  const porIds = async (tabla, ids) => {
    if (!ids.length) return [];
    const r = await listar(tabla, filtroIds(ids));
    return r.filter((x) => ids.includes(x.id)); // capa 3: solo registros pedidos por ID
  };

  return {
    async obtener({ sub }) {
      if (typeof sub !== 'string' || !sub.trim() || CONTROL.test(sub)) return { estado: 'not-connected' };
      const C = CAMPOS.contactos;

      // 1) Contacto por Auth0 ID (igualdad exacta, comprobada otra vez en código).
      const candidatos = await listar(TABLAS.contactos, `TRIM({${C.auth0}})="${esc(sub)}"`);
      const contactos = candidatos.filter((r) => texto(campo(r, C.auth0)) === sub);
      if (contactos.length === 0) return { estado: 'not-connected' };
      if (contactos.length > 1) { log('mi-sml: Auth0 ID duplicado en Contactos; no se muestran datos'); return { estado: 'not-connected' }; }
      const contacto = contactos[0];

      // 2) Registros relacionados, por los IDs del propio contacto.
      const [bonos, pagos, analisis] = await Promise.all([
        porIds(TABLAS.bonos, idsDe(campo(contacto, C.bonos))),
        porIds(TABLAS.pagos, idsDe(campo(contacto, C.pagos))),
        porIds(TABLAS.analisis, idsDe(campo(contacto, C.analisis))),
      ]);

      // Plan vigente: bonos con estado vigente (o todos si no hay campo de estado); si hay varios, el más reciente.
      const B = CAMPOS.bonos;
      const vigentes = bonos.filter((r) => !B.estado || BONO_VIGENTE.includes(texto(campo(r, B.estado)))).sort(masReciente);
      const bono = vigentes[0] || null;
      const contratadas = bono ? numero(campo(bono, B.contratadas)) : null;
      const realizadas = bono ? numero(campo(bono, B.realizadas)) : null;
      let restantes = bono ? numero(campo(bono, B.restantes)) : null;
      if (restantes === null && contratadas !== null && realizadas !== null) restantes = contratadas - realizadas;
      if (restantes !== null) restantes = Math.max(0, restantes); // nunca negativo (p. ej. más sesiones registradas que contratadas)

      // Pago: importe pendiente = suma de los pendientes; estado = el del pago más reciente con importe pendiente, o si no hay, el del pago más reciente. Con CAMPOS.pagos.pendiente = null (hoy) no hay importe pendiente y el estado es el del pago más reciente.
      const P = CAMPOS.pagos;
      const ordenados = [...pagos].sort(masReciente);
      const pendientes = ordenados.map((r) => numero(campo(r, P.pendiente)));
      const hayImportes = pendientes.some((n) => n !== null);
      const importePendiente = hayImportes ? Math.round(pendientes.reduce((s, n) => s + (n ?? 0), 0) * 100) / 100 : null;
      const conDeuda = ordenados.find((r) => (numero(campo(r, P.pendiente)) ?? 0) > 0);
      const pago = { estado: texto(campo(conDeuda || ordenados[0], P.estado)) ?? null, importePendiente };

      // Movement Analysis: solo los marcados «Visible al cliente»; el texto sale solo de los campos «Texto cliente — …» (nunca de los campos internos).
      const A = CAMPOS.analisis;
      const movementAnalysis = analisis
        .filter((r) => campo(r, A.visible) === true)
        .sort(masReciente)
        .map((r) => ({ titulo: texto(campo(r, A.titulo)), resumen: unirTextos([A.resumen].flat().map((n) => campo(r, n))), fecha: texto(campo(r, A.fecha)) }));

      return {
        estado: 'connected',
        client: {
          nombre: texto(campo(contacto, C.nombre)),
          plan: bono ? (texto(campo(bono, B.plan)) ?? texto(campo(bono, B.planRespaldo))) : null,
          pago,
          clases: { contratadas, realizadas, restantes },
          movementAnalysis,
        },
      };
    },
  };
}
