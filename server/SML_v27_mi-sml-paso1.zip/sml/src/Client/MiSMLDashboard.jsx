import { useEffect, useState } from 'react';
import { getCurrentClient, signOut } from './clientApi.js';

// MI SML · zona privada tras la autenticación. Solo se monta con sesión válida (MiSML.jsx).
// Pide los datos a clientApi.getCurrentClient() (única fuente: GET /api/mi-sml/me → Airtable, solo en servidor) y los muestra tal cual los entrega la API.
// Un dato que la API devuelve como null se muestra como «—»: nada se calcula ni se completa aquí. Si la API no tiene datos de esta persona
// (cuenta sin cliente vinculado en Airtable) responde 'not-connected' y no se muestra ningún dato.

const dato = (v) => (v === null || v === undefined || v === '' ? '—' : v);
const euros = (n) => (typeof n === 'number' ? new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(n) : '—');

function Fila({ etiqueta, valor }) {
  return (
    <div className="msml__row">
      <dt>{etiqueta}</dt>
      <dd>{valor}</dd>
    </div>
  );
}

export default function MiSMLDashboard({ onSessionEnded }) {
  const [estado, setEstado] = useState({ status: 'loading' });

  useEffect(() => {
    let vivo = true;
    getCurrentClient()
      .then((client) => { if (vivo) setEstado({ status: 'ready', client }); })
      .catch((error) => {
        if (!vivo) return;
        if (error?.code === 'unauthenticated') { onSessionEnded?.(); return; } // la API rechazó la sesión (caducada o no válida)
        setEstado({ status: error?.code === 'not-connected' ? 'pending' : 'error' });
      });
    return () => { vivo = false; };
  }, []);

  const salir = async () => { try { await signOut(); } catch { /* el cierre falló: la sesión sigue abierta y se queda en pantalla */ } }; // con Auth0, signOut redirige fuera

  const c = estado.status === 'ready' ? estado.client : null;
  const analisis = Array.isArray(c?.movementAnalysis) ? c.movementAnalysis : [];

  return (
    <section className="msml__panel" aria-label="Mi SML">
      <h1 className="msml__title">Mi SML</h1>
      {estado.status === 'loading' && <p className="msml__status" role="status" aria-live="polite">Cargando…</p>}
      {estado.status === 'pending' && <p className="msml__note">Tu zona privada está activa. Tus datos todavía no están disponibles.</p>}
      {estado.status === 'error' && <p className="msml__note" role="alert">No hemos podido cargar tus datos.</p>}
      {c && (
        <>
          {c.nombre && <p className="msml__lead">{c.nombre}</p>}
          <dl className="msml__data">
            <Fila etiqueta="Plan actual" valor={dato(c.plan)} />
            <Fila etiqueta="Estado de pago" valor={dato(c.pago?.estado)} />
            <Fila etiqueta="Importe pendiente" valor={euros(c.pago?.importePendiente)} />
            <Fila etiqueta="Clases contratadas" valor={dato(c.clases?.contratadas)} />
            <Fila etiqueta="Clases realizadas" valor={dato(c.clases?.realizadas)} />
            <Fila etiqueta="Clases restantes" valor={dato(c.clases?.restantes)} />
          </dl>
          <h2 className="msml__kicker">Movement Analysis</h2>
          {analisis.length === 0
            ? <p className="msml__note">Todavía no hay ningún análisis disponible.</p>
            : (
              <ul className="msml__analysis">
                {analisis.map((a, i) => (
                  <li key={i}>
                    {(a.titulo || a.fecha) && <p className="msml__kicker">{[a.titulo, a.fecha].filter(Boolean).join(' · ')}</p>}
                    {a.resumen && <p className="msml__lead">{a.resumen}</p>}
                  </li>
                ))}
              </ul>
            )}
        </>
      )}
      <button type="button" className="msml__btn msml__btn--ghost" onClick={salir}>Salir</button>
    </section>
  );
}
