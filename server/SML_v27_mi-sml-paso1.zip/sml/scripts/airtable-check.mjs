// Contrasta TABLAS/CAMPOS de server/miSmlAirtable.js con la estructura REAL de la base (API de metadatos). Imprime solo NOMBRES de tablas y campos:
// no lee ni imprime registros ni el token. Uso:  AIRTABLE_TOKEN=pat… node scripts/airtable-check.mjs   (el PAT necesita además el scope schema.bases:read)
import { BASE_ID_POR_DEFECTO, TABLAS, CAMPOS } from '../server/miSmlAirtable.js';

const token = (process.env.AIRTABLE_TOKEN || '').trim();
const baseId = (process.env.AIRTABLE_BASE_ID || '').trim() || BASE_ID_POR_DEFECTO;
if (!token) { console.error('Falta AIRTABLE_TOKEN en el entorno.'); process.exit(2); }

const res = await fetch(`https://api.airtable.com/v0/meta/bases/${baseId}/tables`, { headers: { authorization: `Bearer ${token}` } });
if (!res.ok) { console.error(`Airtable respondió ${res.status}. ¿El token tiene el scope schema.bases:read y acceso a la base ${baseId}?`); process.exit(2); }
const { tables } = await res.json();
const porNombre = new Map(tables.map((t) => [t.name, new Set(t.fields.map((f) => f.name))]));

let faltan = 0;
for (const [clave, tabla] of Object.entries(TABLAS)) {
  const campos = porNombre.get(tabla);
  if (!campos) { console.log(`✗ Tabla «${tabla}» NO existe. Tablas reales: ${[...porNombre.keys()].join(' | ')}`); faltan++; continue; }
  console.log(`✓ Tabla «${tabla}»`);
  for (const [rol, valor] of Object.entries(CAMPOS[clave])) {
    if (valor === null) { console.log(`    · ${rol}: (no usado)`); continue; }
    for (const nombre of [valor].flat()) { // un rol puede tener varios nombres (p. ej. analisis.resumen)
      if (campos.has(nombre)) console.log(`    ✓ ${rol}: «${nombre}»`);
      else { faltan++; console.log(`    ✗ ${rol}: «${nombre}» NO existe. Campos reales: ${[...campos].join(' | ')}`); }
    }
  }
}
console.log(faltan ? `\n${faltan} desajuste(s): corrige CAMPOS/TABLAS en server/miSmlAirtable.js o crea el campo en Airtable.` : '\nTodo coincide.');
process.exit(faltan ? 1 : 0);
