// API privada de MI SML — Netlify Functions. Ruta pública: GET /api/mi-sml/me (ver netlify.toml). Lógica en server/miSml.js.
// Valida la sesión de Auth0, identifica a la persona por su token (sub) y consulta Airtable (solo aquí, en servidor) con esa identidad.
// Variables de servidor: AUTH0_DOMAIN, AUTH0_AUDIENCE, AIRTABLE_TOKEN (y opcional AIRTABLE_BASE_ID). Sin AIRTABLE_TOKEN → «datos no conectados».
import { atender, cabeceras, sinFuenteDeDatos } from '../../server/miSml.js';
import { configurado, crearVerificador } from '../../server/miSmlAuth.js';
import { configuradoAirtable, crearFuenteAirtable } from '../../server/miSmlAirtable.js';

let verify = null; // una sola instancia por contenedor (conserva el JWKS en caché)
let fuente = null;

const responder = (r) => new Response(JSON.stringify(r.body), { status: r.status, headers: cabeceras(r.headers) });

export default async (req) => {
  try {
    if (!configurado()) {
      console.error('mi-sml: faltan AUTH0_DOMAIN / AUTH0_AUDIENCE en las variables de entorno del servidor');
      return responder({ status: 500, body: { error: 'internal' } });
    }
    verify ||= crearVerificador();
    if (!fuente) {
      if (!configuradoAirtable()) console.error('mi-sml: falta AIRTABLE_TOKEN en las variables de entorno del servidor; los datos no se conectan');
      fuente = configuradoAirtable() ? crearFuenteAirtable() : sinFuenteDeDatos;
    }
    return responder(await atender(
      { method: req.method, pathname: new URL(req.url).pathname, authorization: req.headers.get('authorization') },
      { verify, fuente },
    ));
  } catch (err) {
    console.error('mi-sml: error interno', err?.name || 'desconocido');
    return responder({ status: 500, body: { error: 'internal' } });
  }
};
